"""
Function to return the number given plus 1 
"""
def add_one(number)-> int:
    return number + 1